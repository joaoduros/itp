function aviso() {
    alert("Para fazer um pedido suporte poderá fazer através do email suporte@itpoweron.pt ou pelo número de telefone 218 059 428.\nO nosso horário de suporte nos dias úteis (segunda a sexta-feira, exceto feriados) é das 9h00 às 13h00 e das 14h30 às 18h30.")
}

